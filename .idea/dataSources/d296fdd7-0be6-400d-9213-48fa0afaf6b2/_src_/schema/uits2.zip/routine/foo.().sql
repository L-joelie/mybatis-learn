CREATE PROCEDURE foo()
  begin
set @frontUpt=0;
set @frontDownt=0;
set @endUpt=0;
set @endDownt=0;
set @p_dev_id=2018;
set @cdate=10;

set @busid='4260,4261,4268,4283,4968,5965';
set @i=1;
while @i<=6 do
	while @cdate<=25 do
	  set @tablename=concat('`uits_cnt_log_t_2018-03-',@cdate,'`');
	  set @frontUp=0;
	  set @frontDown=0;
	  set @endUp=0;
	  set @endDown=0;
	  set @busIdt=substring_index(@busid, ',' ,@i);
	  set @sql1=concat('select sum(cnt_up), sum(cnt_down) into @frontUp,@frontDown from ',@tablename,' where dev_id = @busIdt and cnt_worker_id=0');
	  set @sql2=concat('select sum(cnt_up), sum(cnt_down) into @endUp,@endDown from ',@tablename,' where dev_id = @busIdt and cnt_worker_id=1');
	  prepare stmt1 from @sql1;  
	  EXECUTE stmt1;
	  prepare stmt2 from @sql2;  
	  EXECUTE stmt2;  
	  set @cdate=@cdate+1;
	  set @frontUpt = @frontUpt + @frontUp;
	  set @frontDownt = @frontDownt + @frontDown;
	  set @endUpt = @endUpt + @endUp;
	  set @endDownt = @endDownt + @endDown;
	end while;
	
	insert into utmp values (@busIdt,@frontUpt,@frontDownt,@endUpt,@endDownt);
	set @i = @i+1;
end while;
END;
