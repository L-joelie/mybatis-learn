CREATE VIEW v AS
  (SELECT
     `a`.`bus_name` AS `bus_name`,
     `b`.`bus_type` AS `bus_type`
   FROM (`uits2`.`uits_bus_t` `a` LEFT JOIN `uits2`.`bus_type` `b` ON ((`a`.`bus_name` = `b`.`bus_name`)))
   WHERE ((`a`.`bus_active` = 1) AND (`a`.`bus_plate` <> '')));
